package com.mangaflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val bg = Color(0xFF101114)
private val panel = Color(0xFF1A1C21)
private val accent = Color(0xFFB6F36B)
private val muted = Color(0xFF9A9DA7)
data class Manga(val id:Int,val title:String,val genre:String,val desc:String,val chapters:Int,val emoji:String,val color:Color)
private val catalog = listOf(
 Manga(1,"The Ember Knight","Action • Fantasy","A clever underdog steps into a dangerous world where strength is everything.",142,"⚔️",Color(0xFF563C35)),
 Manga(2,"Moonlit Garden","Romance • Drama","Two strangers meet in a quiet garden where secrets bloom after dark.",68,"🌙",Color(0xFF343D58)),
 Manga(3,"Dungeon Reset","Adventure • Fantasy","Trapped in a deadly dungeon, one player discovers an unexpected loophole.",210,"🌀",Color(0xFF355247)),
 Manga(4,"Starfall Academy","School • Sci-Fi","A new student uncovers the strange truth behind the stars above campus.",54,"✨",Color(0xFF51416B)),
 Manga(5,"Iron & Ash","Action • Seinen","A retired warrior is pulled back into a conflict he thought had ended.",97,"🔥",Color(0xFF674332)),
 Manga(6,"Little Witch Cafe","Slice of Life • Fantasy","A young witch opens a cafe for magical creatures and ordinary people.",35,"☕",Color(0xFF67533B)),
 Manga(7,"Blue Horizon","Sports • Drama","A small-town team fights to reach the national volleyball finals.",121,"🏐",Color(0xFF34546A)),
 Manga(8,"Ghost Signal","Mystery • Supernatural","A radio operator hears messages from a city that disappeared years ago.",43,"👻",Color(0xFF3F4653))
)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
 val prefs=getSharedPreferences("mangaflow",MODE_PRIVATE)
 setContent {
  var tab by remember { mutableStateOf("Home") }
  var query by remember { mutableStateOf("") }
  var selected by remember { mutableStateOf<Manga?>(null) }
  var reader by remember { mutableStateOf(false) }
  var page by remember { mutableIntStateOf(1) }
  var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet())?.toSet()?: emptySet()) }
  var downloads by remember { mutableStateOf(prefs.getStringSet("downloads", emptySet())?.toSet()?: emptySet()) }
  MaterialTheme(colorScheme=darkColorScheme(background=bg,surface=panel,primary=accent,onPrimary=Color(0xFF17200D),onBackground=Color.White,onSurface=Color.White)){
   Surface(Modifier.fillMaxSize(),color=bg){
    when {
     reader && selected!=null -> Column(Modifier.fillMaxSize().background(Color(0xFF08090B))){
      Row(Modifier.fillMaxWidth().background(panel).padding(10.dp),verticalAlignment=Alignment.CenterVertically){
       IconButton(onClick={reader=false}){Icon(Icons.Default.ArrowBack,"Back")}
       Column(Modifier.weight(1f)){Text(selected!!.title,fontWeight=FontWeight.Bold);Text("Chapter preview",color=muted,fontSize=11.sp)}
      }
      Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp).background(Color(0xFF17191E),RoundedCornerShape(12.dp)).clickable{page=page%8+1},contentAlignment=Alignment.Center){
       Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(24.dp)){
        Text(selected!!.emoji,fontSize=68.sp);Text("MANGAFLOW",color=accent,letterSpacing=4.sp)
        Text("Reader preview",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=18.dp))
        Text("Real chapter pages are not bundled. Import local images or connect an authorized source in a future version.",color=muted)
        Text("Page $page / 8",color=accent,modifier=Modifier.padding(top=16.dp))
       }
      }
      Button(onClick={page=page%8+1},modifier=Modifier.fillMaxWidth().padding(12.dp),colors=ButtonDefaults.buttonColors(containerColor=accent,contentColor=Color.Black)){Text("Next page")}
     }
     selected!=null -> Column(Modifier.fillMaxSize().padding(16.dp)){
      TextButton(onClick={selected=null}){Text("← Back",color=accent)}
      Row(verticalAlignment=Alignment.Top){
       Box(Modifier.size(120.dp,165.dp).background(selected!!.color,RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Text(selected!!.emoji,fontSize=50.sp)}
       Column(Modifier.weight(1f).padding(start=14.dp)){
        Text(selected!!.title,fontSize=23.sp,fontWeight=FontWeight.Bold)
        Text(selected!!.genre,color=accent,fontSize=12.sp)
        Text("${selected!!.chapters} chapters",color=muted,modifier=Modifier.padding(top=6.dp))
        Button(onClick={reader=true;page=1},modifier=Modifier.fillMaxWidth().padding(top=10.dp),colors=ButtonDefaults.buttonColors(containerColor=accent,contentColor=Color.Black)){Text("Start reading")}
        OutlinedButton(onClick={
         val id=selected!!.id.toString();bookmarks=if(id in bookmarks)bookmarks-id else bookmarks+id
         prefs.edit().putStringSet("bookmarks",bookmarks).apply()
        },modifier=Modifier.fillMaxWidth()){Text(if(selected!!.id.toString() in bookmarks)"✓ In library" else "+ Add to library")}
        OutlinedButton(onClick={
         downloads=downloads+selected!!.id.toString();prefs.edit().putStringSet("downloads",downloads).apply()
        },modifier=Modifier.fillMaxWidth()){Text("Save demo offline")}
       }
      }
      Text("ABOUT",color=muted,fontSize=11.sp,modifier=Modifier.padding(top=18.dp))
      Text(selected!!.desc,modifier=Modifier.padding(vertical=8.dp))
      Text("CHAPTERS",color=muted,fontSize=11.sp,modifier=Modifier.padding(vertical=8.dp))
      LazyColumn { items(selected!!.chapters.coerceAtMost(30)){i->Row(Modifier.fillMaxWidth().clickable{reader=true;page=1}.padding(vertical=13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Chapter ${selected!!.chapters-i}");Text("Tap to open preview",color=muted,fontSize=11.sp)};Icon(Icons.Default.ChevronRight,null,tint=accent)};HorizontalDivider(color=Color(0xFF282A30))} }
     }
     else -> Scaffold(containerColor=bg,bottomBar={
      NavigationBar(containerColor=panel){listOf("Home","Library","Browse","Downloads","Settings").forEach{label->
       val icon=when(label){"Home"->Icons.Default.Home;"Library"->Icons.Default.Bookmarks;"Browse"->Icons.Default.Explore;"Downloads"->Icons.Default.Download;else->Icons.Default.Settings}
       NavigationBarItem(selected=tab==label,onClick={tab=label},icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=accent,selectedTextColor=accent,indicatorColor=Color(0xFF303B25),unselectedIconColor=muted,unselectedTextColor=muted))
      }}
     }){padding->Column(Modifier.fillMaxSize().padding(padding)){
      Column(Modifier.padding(horizontal=18.dp, vertical=18.dp)){Text("MANGAFLOW",color=accent,fontSize=12.sp,letterSpacing=3.sp,fontWeight=FontWeight.Bold);Text(when(tab){"Home"->"Your next obsession.";"Library"->"Your collection.";"Browse"->"Find a new story.";"Downloads"->"Ready for offline.";else->"Make it yours."},fontSize=23.sp,fontWeight=FontWeight.Bold)}
      if(tab=="Settings"){
       Column(Modifier.padding(horizontal=18.dp)){listOf("Appearance" to "Dark theme • Lime accent","Reader" to "Reader preview available","Downloads" to "Demo saved titles only","Sources" to "Online source adapters not configured","About MangaFlow" to "Version 0.1.0").forEach{(a,b)->Column(Modifier.fillMaxWidth().padding(vertical=15.dp)){Text(a,fontWeight=FontWeight.Bold);Text(b,color=muted,fontSize=12.sp)};HorizontalDivider(color=Color(0xFF282A30))}}
      }else{
       OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp),placeholder={Text("Search manga, manhwa, genres…",color=muted)},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(14.dp))
       Text(if(tab=="Home")"POPULAR THIS WEEK" else "${tab.uppercase()} • ${if(tab=="Library")bookmarks.size else if(tab=="Downloads")downloads.size else catalog.size} TITLES",color=muted,fontSize=10.sp,letterSpacing=2.sp,modifier=Modifier.padding(start=20.dp,top=16.dp,bottom=12.dp))
       val list=catalog.filter{m->(tab!="Library"||m.id.toString() in bookmarks)&&(tab!="Downloads"||m.id.toString() in downloads)&&(m.title.contains(query,true)||m.genre.contains(query,true))}
       LazyVerticalGrid(columns=GridCells.Fixed(2),contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(14.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
        items(list){m->Column(Modifier.fillMaxWidth().clickable{selected=m}){
         Box(Modifier.fillMaxWidth().height(185.dp).background(m.color,RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Text(m.emoji,fontSize=60.sp);Text("DEMO",color=accent,fontSize=9.sp,modifier=Modifier.align(Alignment.TopStart).padding(8.dp));Text("${m.chapters} ch",fontSize=10.sp,modifier=Modifier.align(Alignment.BottomEnd).padding(8.dp))}
         Text(m.title,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(top=8.dp))
         Text(m.genre,color=muted,fontSize=11.sp,maxLines=1)
        }}
       }
      }
     }}
    }
   }
  }
 }
}

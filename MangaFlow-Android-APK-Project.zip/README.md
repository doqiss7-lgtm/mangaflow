# MangaFlow Android APK project

This is a native Android project for MangaFlow, a Mihon-inspired manga-reader prototype. It contains a working catalog UI, search, local library bookmarks, chapter list, and a reader preview.

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show a link to the generated APK.

## Current limitations
This is not a prebuilt APK. This environment cannot run Android Gradle builds or sign and test an APK. Online content sources, real chapter images, and actual offline downloads are not included. Use content sources you are authorized to access.
